namespace Ejercicio03CRUD.Views;

public partial class ListadoDepartamentosPage : ContentPage
{
	public ListadoDepartamentosPage()
	{
		InitializeComponent();
	}
}