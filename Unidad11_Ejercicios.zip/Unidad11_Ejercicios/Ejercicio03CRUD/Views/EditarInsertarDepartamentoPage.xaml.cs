namespace Ejercicio03CRUD.Views;

public partial class EditarInsertarDepartamentoPage : ContentPage
{
	public EditarInsertarDepartamentoPage()
	{
		InitializeComponent();
	}
}