﻿using Ejercicio03CRUD.ViewModels;

namespace Ejercicio03CRUD.Views;

public partial class MainPage : ContentPage
{

    public MainPage()
    {
        InitializeComponent();
    }

}
