namespace Ejercicio03CRUD.Views;

public partial class ListadoPersonasPage : ContentPage
{
	public ListadoPersonasPage()
	{
		InitializeComponent();
	}
}