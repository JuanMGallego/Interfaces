﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using DAL;
using Entidades;

namespace BL
{
    public class ClsListadosPersonasBL
    {

        
    }
}