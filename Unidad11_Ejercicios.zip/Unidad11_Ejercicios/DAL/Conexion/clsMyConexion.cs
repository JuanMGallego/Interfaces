﻿namespace DAL.Conexion
{
    /// <summary>
    /// Clase para tener la conexión con la API
    /// </summary>
    public static class clsMyConexion
    {
        public static string getUriBase()
        {
            return "https://crudnervion.azurewebsites.net/api/";
        }
    }

}
